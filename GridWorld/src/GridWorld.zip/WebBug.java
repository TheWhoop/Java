import java.awt.Color;
import info.gridworld.actor.Bug;

public class WebBug extends Bug { 
	public WebBug() {
		setColor(Color.white);
	}
	public void act() { 

	}
}