import info.gridworld.actor.Critter;
import java.awt.Color;

public class WebCritter extends Critter{
	public WebCritter(){
		setColor(Color.WHITE);
	}
	public void act() {
		
	}
}